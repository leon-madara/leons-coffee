// src/components/HistoryOnHover.tsx
import React from 'react';
import styles from './HistoryOnHover.module.css';

interface Props {
  imgSrc: string;
  alt: string;
  text: string;
}

const HistoryOnHover: React.FC<Props> = ({ imgSrc, alt, text }) => (
  <div className={styles.interactive}>
    <div className={styles.imageWrapper}>
      <img src={imgSrc} alt={alt} className={styles.image} />
    </div>
    <div className={styles.textWrapper}>
      <p className={styles.text}>{text}</p>
    </div>
  </div>
);

export default HistoryOnHover;