// src/components/OurHistory/OurHistory.tsx
import React from 'react'
import styles from './OurHistory.module.css'
import HistoryOnHover from './HistoryOnHover/HistoryOnHover'

// Import images with correct relative path
import scene1Img from '../../images/history1.png'
import scene2Img from '../../images/history2.png'
import scene3Img from '../../images/history3.png'
import scene4Img from '../../images/history4.png'
import scene5Img from '../../images/history5.png'
import backgroundImg from '../../images/our history1.png'
import historyImg from '../../images/historyBG.png'

interface SceneDetail {
  id: number
  imgSrc: string
  alt: string
  text: string
}

const details: SceneDetail[] = [
  {
    id: 1,
    imgSrc: scene1Img,
    alt: 'Origin Moment',
    text: `It all started in 1987 when Leon CoffeeMan, a brilliant yet eccentric mathematician, grew disillusioned with numbers and equations. One late night, frustrated by a miscalculation after 16 hours of complex work, he accidentally used his coffee-to-water ratio instead of a quantum formula. The result? A cup of coffee so perfect, it was borderline divine. That one error became the defining moment of Leon's new obsession.`,
  },
  {
    id: 2,
    imgSrc: scene2Img,
    alt: 'Golden Ratio Discovery',
    text: `The First Brew Inspired by his "golden ratio" discovery, Leon scraped together $500, claimed a vintage espresso machine he'd won at a chess tournament, and opened a tiny 200-square-foot shop tucked in the corner of an old bookstore. He fine-tuned his coffee algorithm and served his first customer — none other than the professor who once failed his thesis for being "too obsessed with coffee references.`,
  },
  {
    id: 3,
    imgSrc: scene3Img,
    alt: 'First Shop Startup',
    text: `The Growing Legend Word spread quickly about the genius who could calculate the exact extraction time of the perfect cup. People were intrigued by his methods, and even more by the coffee. Soon, a line of caffeine lovers, curious students, and mathematical hobbyists stretched around the block. Leon's precision-driven approach made coffee drinking an intellectual experience.`,
  },
  {
    id: 4,
    imgSrc: scene4Img,
    alt: 'Viral Word-of-Mouth',
    text: `The Expansion As the demand grew, so did the legend. Leon's Coffee expanded gradually, maintaining its quirky blend of science and warmth. Each new location used his original brewing equations—now securely locked in a temperature-controlled safe. Training baristas became an academic pursuit, requiring a deep understanding of the chemistry behind every brew.`,
  },
  {
    id: 5,
    imgSrc: scene5Img,
    alt: 'Modern Expansion',
    text: `Today's Legacy Today, Leon's Coffee has grown into a national presence, with fifteen locations and a loyal following. But even with modern aesthetics and advanced equipment, every shop is grounded in Leon's vision: brewing coffee through exacting science and heartfelt connection. As we say—we don't just make coffee; we engineer it.`,
  },
]

const OurHistory: React.FC = () => {
  return (
    <div className={styles.pageContainer}>
      <h1 className={styles.title}>Our History</h1>

      {/* 0) Glass‑morphic thumbnail gallery wrapper */}
      <div className={styles.thumbnailBox}>
        {/* Background div with blur effect */}
        <div className={styles.blurredBackground} style={{ backgroundImage: `url(${backgroundImg})` }} />
        
        {/* 1) Thumbnail strip - now separate from the background */}
        <div className={styles.sceneThumbnails}>
          {details.map((detail) => (
            <div key={detail.id} className={styles.thumbnailContainer}>
              <img
                src={detail.imgSrc}
                alt={detail.alt}
                className={styles.thumbnailImage}
              />
            </div>
          ))}
        </div>
      </div>

      {/* 2) Summary only and history image*/}
      <div className={styles.displayArea}>
        <p className={styles.summary}>
          <img
            src={historyImg}
            alt="Leon's Coffee in 1987"
            className={styles.historyImg}
          />
          Leon's Coffee began in 1987 when Leon CoffeeMan, a quirky mathematician frustrated with abstract equations, accidentally unlocked the secret to the perfect brew. After sixteen hours of late‑night number‑crunching, he mistakenly applied his coffee‑to‑water ratio in place of a quantum mechanics formula—and found himself tasting the richest, most harmonious cup of coffee he'd ever experienced. Word spread rapidly through campus corridors and neighborhood cafés as students, professors, and curious passersby lined up each morning to sample this unexpected delight.<br />
          With just five hundred dollars, a vintage espresso machine won in a chess tournament, and his original brewing algorithm, Leon opened a tiny, 200‑square‑foot shop nestled in the corner of an old bookstore. His first customer was the very professor who once failed his thesis for excessive coffee references. What began as a serendipitous mistake grew into a national obsession—fifteen thriving locations later, every barista still trains using Leon's "golden ratio" to ensure each cup remains as precise and delicious as that very first brew.
        </p>
      </div>

      {/* 3) Interactive hover details, controlled via CSS */}
      <div className={styles.interactiveHover}>
        {details.map((detail) => (
          <div
            key={detail.id}
            className={`${styles.sceneContent} ${styles[`scene${detail.id}`]}`}
          >
            <HistoryOnHover
              imgSrc={detail.imgSrc}
              alt={detail.alt}
              text={detail.text}
            />
          </div>
        ))}
      </div>
    </div>
  )
}

export default OurHistory